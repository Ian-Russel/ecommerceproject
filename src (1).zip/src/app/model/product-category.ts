import { Product } from "./product";

export class ProductCategory  {
    categoryName: string = "";
    products: Product[] = [];
}
