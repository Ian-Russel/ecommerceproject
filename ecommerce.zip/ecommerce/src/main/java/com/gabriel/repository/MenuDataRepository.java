package com.gabriel.repository;

import com.gabriel.entity.MenuData;
import org.springframework.data.repository.CrudRepository;

public interface MenuDataRepository extends CrudRepository<MenuData,Integer> {
}
