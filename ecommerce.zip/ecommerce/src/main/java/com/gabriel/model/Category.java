package com.gabriel.model;

public class Category {
    int id;
    String name;
    String description;
}
